<?php

class zbx_maps
{

	private static $instance = null;
	static $get = null;

	static function get_instance()
	{
		if (!self::$instance) {
			self::$instance = new zbx_maps();
		}
	}

	public static function get($setting)
	{
		return self::$get[$setting];
	}

	/**
	 * * @usage zbx_builder::add_to_map($zbx_map_name, zbx_maps::margin() );
	 * @return array
	 */
	public static function margin()
	{

		return array(
			// Padding

			array(
				'type'       => 'info',
				'heading'    => __('Info', 'pixo'),
				'param_name' => 'info',
				'image'      => ZORBIX_IMG . 'padding-margin.svg',
				'group'      => esc_html__('margin', 'pixo'),
			),

			array(
				'type'        => 'textfield',
				'holder'      => 'div',
				'heading'     => __('Margin', 'pixo'),
				'param_name'  => 'margin',
				'description' => esc_html__('Via inline style', 'pixo'),
				'group'       => esc_html__('margin', 'zorbix'),
			),
			array(
				'type'        => 'textfield',
				'holder'      => 'div',
				'heading'     => __(' Top', 'pixo'),
				'param_name'  => 'margin_top',
				'description' => esc_html__('Via inline style', 'pixo'),
				'group'       => esc_html__('margin', 'zorbix'),
			),

			array(
				'type'        => 'textfield',
				'holder'      => 'div',
				'heading'     => __(' Right', 'pixo'),
				'param_name'  => 'margin_right',
				'description' => esc_html__('Via inline style', 'pixo'),
				'group'       => esc_html__('margin', 'zorbix'),
			),
			array(
				'type'        => 'textfield',
				'holder'      => 'div',
				'heading'     => __(' Bottom', 'pixo'),
				'param_name'  => 'margin_bottom',
				'description' => esc_html__('Via inline style', 'pixo'),
				'group'       => esc_html__('margin', 'zorbix'),
			),
			array(
				'type'        => 'textfield',
				'holder'      => 'div',
				'heading'     => __(' Left', 'pixo'),
				'param_name'  => 'margin_left',
				'description' => esc_html__('Via inline style', 'pixo'),
				'group'       => esc_html__('margin', 'zorbix'),
			)
		);
	}


	/**
	 * @usage zbx_builder::add_to_map($zbx_map_name, zbx_maps::padding() );
	 * @return array
	 */
	public static function padding()
	{

		return array(
			array(
				'type'       => 'info',
				'heading'    => __('Info', 'pixo'),
				'param_name' => 'info',
				'image'      => ZORBIX_IMG . 'padding-margin.svg',
				'group'      => esc_html__('padding', 'pixo'),
			),
			array(
				'type'        => 'textfield',
				'holder'      => 'div',
				'heading'     => __('Padding', 'pixo'),
				'param_name'  => 'padding',
				'description' => esc_html__('Via inline style', 'pixo'),
				'group'       => esc_html__('padding', 'zorbix'),
			),
			array(
				'type'        => 'textfield',
				'holder'      => 'div',
				'heading'     => __('Padding Top', 'pixo'),
				'param_name'  => 'padding_top',
				'description' => esc_html__('Via inline style', 'pixo'),
				'group'       => esc_html__('padding', 'zorbix'),
			),

			array(
				'type'        => 'textfield',
				'holder'      => 'div',
				'heading'     => __('Padding Right', 'pixo'),
				'param_name'  => 'padding_right',
				'description' => esc_html__('Via inline style', 'pixo'),
				'group'       => esc_html__('padding', 'zorbix'),
			),
			array(
				'type'        => 'textfield',
				'holder'      => 'div',
				'heading'     => __('Padding Bottom', 'pixo'),
				'param_name'  => 'padding_bottom',
				'description' => esc_html__('Via inline style', 'pixo'),
				'group'       => esc_html__('padding', 'zorbix'),
			),
			array(
				'type'        => 'textfield',
				'holder'      => 'div',
				'heading'     => __('Padding Left', 'pixo'),
				'param_name'  => 'padding_left',
				'description' => esc_html__('Via inline style', 'pixo'),
				'group'       => esc_html__('padding', 'zorbix'),
			)
		);
	}

	public static function add_icon_map($options = array())
	{

		$default = array(
			'group'    => 'Icon',
			'postfix'  => '',
			'optional' => false,
			'icon-bg'  => false,
			'icon-border'  => false,
		);

		if (is_array($options)) {
			$options = array_merge(
				$default,
				$options
			);
		}

		return self::set_icon_fields($options);
	}

	public static function add_social_map($sc)
	{

		$params = array(
			array(
				'type'        => 'dropdown',
				'holder'      => 'div',
				'heading'     => __('Social', 'pixo'),
				'param_name'  => 'social',
				'description' => __('Choose social fields', 'pixo'),
				'value'       => '', // Default
			),
		);

		vc_add_params($sc, $params);
	}

	public static function  set_icon_fields($options = array())
	{

		$default = array(
			'group'    => 'Icon',
			'postfix'  => '',
			'optional' => false,
			'icon-bg'  => false,
			'icon-border'  => false,
		);

		if (!is_array($options)) {
			$options = array();
		}

		$options = array_merge(
			$default,
			$options
		);

		//$optional = false, $postfix = '', $group = 'Icon'l
		//
		$postfix = (!empty($options['postfix'])) ? '_' . $options['postfix'] : '';

		$dropdown = array(
			'type'       => 'colorpicker',
			'group'      => 'icon',
			'heading'    => __('Icon Color', 'pixo'),
			'param_name' => 'icon_color' . $postfix,
			'group'      => $options['group'],
		);

		$params[] = $dropdown;

//		$params[] = $dropdown;

		if (true === $options['icon-border']) {

			$params[] = array(
					'type'       => 'colorpicker',
					'heading'    => esc_html__('Border Color', 'zorbix'),
					'param_name' => 'icon_border' . $postfix,
					'group'      => $options['group'],
					'std'        => '#009EC6'
			);

		}
		if (true === $options['icon-bg']) {

			$params[] = array(
				'type'       => 'colorpicker',
				'heading'    => esc_html__('Background Color', 'zorbix'),
				'param_name' => 'icon_bg' . $postfix,
				'group'      => $options['group'],
				'std'        => '#009EC6'
			);

		}

//		$params[] = array(
//			'type'        => 'dropdown',
//			'heading'     => esc_html__('Icon library', 'zorbix'),
//			'value'       => array(
//				esc_html__('Font Awesome', 'zorbix') => 'fontawesome',
//				esc_html__('Open Iconic', 'zorbix')  => 'openiconic',
//				esc_html__('Typicons', 'zorbix')     => 'typicons',
//				esc_html__('Entypo', 'zorbix')       => 'entypo',
//				esc_html__('Linecons', 'zorbix')     => 'linecons',
////				esc_html__( 'Pixel', 'zorbix' )        => 'pixelicons',
//			),
//			'param_name'  => 'icon_type' . $postfix,
//			'description' => esc_html__('Select icon library.', 'zorbix'),
//			'group'       => $options['group'],
//		);

		if (true === $options['optional']) {

			$params[] = array(
				'type'       => 'checkbox',
				'heading'    => esc_html__('Add Icon?', 'zorbix'),
				'param_name' => 'icon_enable' . $postfix,
				'value'      => array('Yes' => 'true'),
				'group'      => $options['group'],
			);

//			$dropdown['dependency'] = Array('element' => 'icon_enable' . $postfix, 'value' => array('true'));
			$params[] = $dropdown;

		}

//		self::add_param( $dropdown );

		$params[] = array(
			'type'        => 'iconpicker',
			'heading'     => esc_html__('Icon', 'zorbix'),
			'param_name'  => 'icon_fontawesome' . $postfix,
			'value'       => self::get_fontawesome_icons(),
			'group'       => $options['group'],
			'holder'      => 'i',
//			'dependency'  => array(
//				'element' => 'icon_type' . $postfix,
//				'value'   => 'fontawesome',
//			),
			'description' => esc_html__('Select icon from library.', 'zorbix'),
		);

		/* $params[] = array(
			'type'        => 'iconpicker',
			'heading'     => esc_html__( 'Icon', 'zorbix' ),
			'param_name'  => 'icon_openiconic' . $postfix,
			'holder'      => 'i',
			'group'       => $options['group'],
			'settings'    => array(
				'emptyIcon'    => false, // default true, display an "EMPTY" icon?
				'type'         => 'openiconic',
				'iconsPerPage' => 200, // default 100, how many icons per/page to display
			),
			'dependency'  => array(
				'element' => 'icon_type' . $postfix,
				'value'   => 'openiconic',
			),
			'description' => esc_html__( 'Select icon from library.', 'zorbix' ),
		);

		$params[] = array(
			'type'        => 'iconpicker',
			'heading'     => esc_html__( 'Icon', 'zorbix' ),
			'param_name'  => 'icon_typicons' . $postfix,
			'holder'      => 'i',
			'group'       => $options['group'],
			'value' => array(),
			'dependency'  => array(
				'element' => 'icon_type' . $postfix,
				'value'   => 'typicons',
			),
			'description' => esc_html__( 'Select icon from library.', 'zorbix' ),
		);

		$params[] = array(
			'type'       => 'iconpicker',
			'heading'    => esc_html__( 'Icon', 'zorbix' ),
			'param_name' => 'icon_entypo' . $postfix,
			'holder'     => 'i',
			'group'      => $options['group'],
			'settings'   => array(
				'emptyIcon'    => false, // default true, display an "EMPTY" icon?
				'type'         => 'entypo',
				'iconsPerPage' => 300, // default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'icon_type' . $postfix,
				'value'   => 'entypo',
			),
		);

		$params[] = array(
			'type'        => 'iconpicker',
			'heading'     => esc_html__( 'Icon', 'zorbix' ),
			'param_name'  => 'icon_linecons' . $postfix,
			'holder'      => 'i',
			'group'       => $options['group'],
			'settings'    => array(
				'emptyIcon'    => false, // default true, display an "EMPTY" icon?
				'type'         => 'linecons',
				'iconsPerPage' => 200, // default 100, how many icons per/page to display
			),
			'dependency'  => array(
				'element' => 'icon_type' . $postfix,
				'value'   => 'linecons',
			),
			'description' => esc_html__( 'Select icon from library.', 'zorbix' ),
		);

		$params[] = array(
			'type'        => 'iconpicker',
			'heading'     => esc_html__( 'Icon', 'zorbix' ),
			'param_name'  => 'icon_pixelicons' . $postfix,
			'holder'      => 'i',
			'group'       => $options['group'],
			'settings'    => array(
				'emptyIcon' => false, // default true, display an "EMPTY" icon?
				'type'      => 'pixelicons',
				'source'    => self::get_pixel_icons(),
			),
			'dependency'  => array(
				'element' => 'icon_type' . $postfix,
				'value'   => 'pixelicons',
			),
			'description' => esc_html__( 'Select icon from library.', 'zorbix' ),
		); */

		return $params;
	}

	public static function get_fontawesome_icons()
	{

		// scrape list of icons from fontawesome css
		$transient = 'vp_fontawesome_icons_4.0.1';
		if (false === ($icons = get_transient($transient)) || true === ZORBIX_DEBUG) {
			$pattern = '/\.(fa-(?:\w+(?:-)?)+):before\s*{\s*content/';
			$subject = wp_remote_retrieve_body(wp_remote_get(ZORBIX_CSS . 'font-awesome.min.css'));

			preg_match_all($pattern, $subject, $matches, PREG_SET_ORDER);

			$icons['none'] = '';
			foreach ($matches as $match) {
				$icons['fa ' . $match[1]] = $match[1];
			}

			set_transient($transient, $icons, 60 * 60 * 24);
		}

		return $icons;
	}

	public static function get_pixel_icons()
	{
		return array(
			array('vc_pixel_icon vc_pixel_icon-alert' => esc_html__('Alert', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-info' => esc_html__('Info', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-tick' => esc_html__('Tick', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-explanation' => esc_html__('Explanation', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-address_book' => esc_html__('Address book', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-alarm_clock' => esc_html__('Alarm clock', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-anchor' => esc_html__('Anchor', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-application_image' => esc_html__('Application Image', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-arrow' => esc_html__('Arrow', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-asterisk' => esc_html__('Asterisk', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-hammer' => esc_html__('Hammer', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-balloon' => esc_html__('Balloon', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-balloon_buzz' => esc_html__('Balloon Buzz', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-balloon_facebook' => esc_html__('Balloon Facebook', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-balloon_twitter' => esc_html__('Balloon Twitter', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-battery' => esc_html__('Battery', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-binocular' => esc_html__('Binocular', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-document_excel' => esc_html__('Document Excel', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-document_image' => esc_html__('Document Image', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-document_music' => esc_html__('Document Music', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-document_office' => esc_html__('Document Office', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-document_pdf' => esc_html__('Document PDF', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-document_powerpoint' => esc_html__('Document Powerpoint', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-document_word' => esc_html__('Document Word', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-bookmark' => esc_html__('Bookmark', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-camcorder' => esc_html__('Camcorder', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-camera' => esc_html__('Camera', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-chart' => esc_html__('Chart', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-chart_pie' => esc_html__('Chart pie', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-clock' => esc_html__('Clock', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-fire' => esc_html__('Fire', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-heart' => esc_html__('Heart', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-mail' => esc_html__('Mail', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-play' => esc_html__('Play', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-shield' => esc_html__('Shield', 'zorbix')),
			array('vc_pixel_icon vc_pixel_icon-video' => esc_html__('Video', 'zorbix')),
		);
	}

	public static function get_tax_params($tax)
	{
		return array(
			array(
				'group'       => esc_html__('Sets', 'zorbix'),
				'type'        => 'textfield',
				'heading'     => esc_html__('Limit Number', 'zorbix'),
				'param_name'  => 'num',
				'description' => esc_html__('Leave blank for all', 'zorbix'),
			),

			array(
				'group'      => esc_html__('Sets', 'zorbix'),
				'type'       => 'taxonomy',
				'heading'    => esc_html__('Categories', 'zorbix'),
				'taxonomy'   => $tax,
				'param_name' => 'terms',
			),

			array(
				'group'       => esc_html__('Sets', 'zorbix'),
				'type'        => 'checkbox',
				'heading'     => esc_html__('Tick to reverse order', 'zorbix'),
				'param_name'  => 'order',
				'description' => 'IMPORTANT: Not compatible with ordering plugins like `order anything`',
				'value'       => array('' => 'asc'),
			)
		);

	}

	public static function get_social_params()
	{

	}

	public static function get_column_params()
	{
		return array(
			array(
				'group'       => esc_html__('Columns', 'zorbix'),
				'type'        => 'checkbox',
				'heading'     => esc_html__('Center Columns', 'zorbix'),
				'param_name'  => 'center_columns',
				'description' => 'Forces to one column',
				'value'       => array('' => 'cols-centered'),
			),
			array(
				'group'      => esc_html__('Columns', 'zorbix'),
				'type'       => 'checkbox',
				'heading'    => esc_html__('Override Column Settings?', 'zorbix'),
				'param_name' => 'columns_check',
				'value'      => array('' => 'true'),
			),
			array(
				'group'      => esc_html__('Columns', 'zorbix'),
				'type'       => 'dropdown',
				'heading'    => esc_html__('Column Width', 'zorbix'),
				'param_name' => 'col_width',
				'value'      => array(
					'default'    => '',
					'one-half'   => 'col-md-6',
					'one-third'  => 'col-md-4',
					'one-fourth' => 'col-md-3',
					'one-sixth'  => 'col-md-2',
				),
				'dependency' => array('element' => 'columns_check', 'value' => array('true')),
			),
			array(
				'group'       => esc_html__('Columns', 'zorbix'),
				'type'        => 'columns_range',
				'heading'     => esc_html__('Number of Columns', 'zorbix'),
				'param_name'  => 'num_columns',
				'description' => esc_html__('Number of columns per row', 'zorbix'),
				'dependency'  => array('element' => 'columns_check', 'value' => array('true')),
				'value'       => '0',
				'min'         => '0',
				'max'         => '12',
			)
		);

	}


	/**
	 * @return array
	 */
	public static function zbx_image_sizes()
	{
		$zbx_image_sizes = get_intermediate_image_sizes();
		$zbx_image_sizes[] = 'full';
		$zbx_image_sizes = array_combine($zbx_image_sizes, $zbx_image_sizes);
		$zbx_image_sizes = array_map(function ($key) {
			return zbx::id_to_name($key);
		}, $zbx_image_sizes);
		return array_flip($zbx_image_sizes);
	}


	public static function get_image_sizes() {
		global $_wp_additional_image_sizes;

		$sizes = array();
		foreach ( get_intermediate_image_sizes() as $_size ) {
			if (in_array($_size, array('thumbnail', 'medium', 'medium_large', 'large'))) {
				$key = $_size . ' - ' . get_option("{$_size}_size_w") . ', ' . get_option("{$_size}_size_h");
				$sizes[$key] = $_size;
			} elseif (isset($_wp_additional_image_sizes[$_size])) {
				$key = $_size . ' - ' . $_wp_additional_image_sizes[$_size]['width'] . ', ' . $_wp_additional_image_sizes[$_size]['height'];
				$sizes[$key] = $_size;
			}
		}
		return $sizes;
	}

}


add_action('wp_loaded', array('zbx_maps', 'get_instance'));
