<?php
kirki::add_section($zbx_panel_prefix . 'typography',
	array(
		'title'       => esc_html__('Typography ( Text/font/color )', 'pixo'),
		'priority'    => 152,
		'description' => esc_html__('For more advanced customisation see relevant knowledge base articles', 'pixo')
	));


zbx_settings::set_section($zbx_panel_prefix . 'typography');


zbx_settings::add_field(array(
	'type'     => 'typography',
	'settings' => 'body_typography',
	'label'    => 'body',
	'priority' => 10,
	'choices'  => array(
		'font-family'    => true,
		'font-style'     => true,
		'font-size'      => true,
		'font-weight'    => true,
		'line-height'    => true,
//		'letter-spacing' => true,
		'units'          => array('px', 'rem', 'em'),
	),
	'output'   => array(
		array(
			'element' => 'body',
		),
	),
));

zbx_settings::typography(array(
	'heading'     => 'Heading 1',
	'element'     => 'h1',
	'color'       => '#444',
	'font-style'  => array('bold', 'italic'),
	'font-size'   => '14',
	'font-weight' => '300',
	'line-height' => '1.5',
));

zbx_settings::typography(array(
	'heading'     => 'Heading 2',
	'element'     => 'h2',
	'color'       => '#444',
	'font-style'  => array('bold', 'italic'),
	'font-size'   => '14',
	'font-weight' => '300',
	'line-height' => '1.5',
));

zbx_settings::typography(array(
	'heading'     => 'Heading 3',
	'element'     => 'h3',
	'color'       => '#444',
	'font-style'  => array('bold', 'italic'),
	'font-size'   => '14',
	'font-weight' => '400',
	'line-height' => '1.5',
));

zbx_settings::typography(array(
	'heading'     => 'Heading 4',
	'element'     => 'h4',
	'color'       => '#444',
	'font-style'  => array('bold', 'italic'),
	'font-size'   => '14',
	'font-weight' => '300',
	'line-height' => '1.5',
));

zbx_settings::typography(array(
	'heading'     => 'Heading 5',
	'element'     => 'h5',
	'color'       => '#444',
	'font-style'  => array('bold', 'italic'),
	'font-size'   => '14',
	'font-weight' => '300',
	'line-height' => '1.5',
));

zbx_settings::typography(array(
	'heading'     => 'Heading 6',
	'element'     => 'h6',
	'color'       => '#444',
	'font-style'  => array('bold', 'italic'),
//	'font-size'   => '14',
	'font-weight' => '300',
	'line-height' => '1.5',
));

zbx_settings::typography(array(
	'heading'     => 'Paragraph',
	'element'     => 'p',
	'color'       => '#777',
	'font-size'   => '14',
	'font-weight' => '100',
	'line-height' => '1.5',
));
