<?php

$zbx_panel_prefix = 'zbx-';

zbx_settings::set_defaults(array(
	'contact_failed_message'  => esc_html__('Sorry there was a problem sending your message, please try again later', 'pixo'),
	'contact_success_message' => esc_html__('Thank you, your message was sent', 'pixo'),
	'contact_name_error'      => esc_html__('Error please provide your name', 'pixo'),
	'contact_email_error'     => esc_html__('Please provide a valid email address', 'pixo'),
	'contact_message_error'   => esc_html__('Please leave a longer message', 'pixo'),
	'contact_email'           => get_option('admin_email'),
));

zbx_settings::add_section(
	array(
			'name' => $zbx_panel_prefix . 'contact',
		'title'       => esc_html__('Contact', 'zorbix'),
		'priority'    => 152,
		'description' => esc_html__('The built in contact form is deliberately simple. For more advance uses please use a plugin such as contact form 7 ', 'pixo')
	));

zbx_settings::set_section($zbx_panel_prefix . 'contact', 'contact_');

zbx_settings::add_field(array(
	'type'        => 'custom',
	'setting'     => 'contact-info',
	'label'       => __('Info', 'pixo'),
	'description' => __('For building custom forms we recommend Contact Form 7', 'pixo'),
	'priority'    => 10,
));

zbx_settings::add_field(array(
	'type'        => 'custom',
	'setting'     => 'contact-info',
	'label'       => __('Info', 'pixo'),
	'description' => __('Looking to build your own form? Pixo supports Contact Form 7', 'pixo'),
	'priority'    => 10,
));

zbx_settings::add_field(array(
	'type'    => 'text',
	'setting' => 'email',
	'label'   => esc_html__('Contact Email', 'zorbix'),
	'default' => zbx_settings::get_default('contact_email')
));

zbx_settings::add_field(array(
	'type'    => 'text',
	'setting' => 'failed_message',
	'label'   => esc_html__('Failed Message', 'zorbix'),
	'default' => zbx_settings::get_default('contact_failed_message')
));

zbx_settings::add_field(array(
	'type'    => 'text',
	'setting' => 'success_message',
	'label'   => esc_html__('Success Message', 'zorbix'),
	'default' => zbx_settings::get_default('contact_success_message')
));


zbx_settings::add_field(array(
	'type'    => 'text',
	'setting' => 'name_error',
	'label'   => esc_html__('Name Error Message', 'zorbix'),
	'default' => zbx_settings::get_default('contact_name_error')
));


zbx_settings::add_field(array(
	'type'    => 'text',
	'setting' => 'email_error',
	'label'   => esc_html__('Email Error Message', 'zorbix'),
	'default' => zbx_settings::get_default('contact_email_error')
));

zbx_settings::add_field(array(
	'type'    => 'text',
	'setting' => 'message_error',
	'label'   => esc_html__('Content Error Message', 'zorbix'),
	'default' => zbx_settings::get_default('contact_message_error')
));


