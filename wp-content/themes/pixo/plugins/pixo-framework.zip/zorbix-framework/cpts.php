<?php

include ZORBIX_PLUGIN_CPT_CLASSES_DIR . 'cuztom.class.php';
include ZORBIX_PLUGIN_CPT_CLASSES_DIR . 'taxonomy.class.php';
include ZORBIX_PLUGIN_CPT_CLASSES_DIR . 'post_type.class.php';
include ZORBIX_PLUGIN_CLASSES_DIR . 'zorbix_cpt.php';


add_filter('images_cpt', 'zorbix_image_cpt');
function zorbix_image_cpt()
{
	$cpts = array('page', 'project');
	return $cpts;
}

// Testimonial CPT
$zbx_new_cpt = new Zorbix_CPT('Testimonial', array('supports' => array('title', 'thumbnail')));
$zbx_new_cpt->add_taxonomy('Testimonial Slider');
$zbx_new_cpt->add_column(array('category'));

// Post Type
$zbx_cpt = new Zorbix_CPT(
	get_theme_mod('portfolio_custom_post_type', esc_html__('Project', 'pixo')),
	array('supports' => array('title', 'thumbnail', 'editor'))
);
$zbx_cpt->add_taxonomy('Portfolio');
$zbx_cpt->add_column(array('thumbnail', 'category'));

