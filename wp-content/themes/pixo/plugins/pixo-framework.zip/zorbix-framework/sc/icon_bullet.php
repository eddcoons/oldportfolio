<?php

add_shortcode('icon_bullet', 'zbx_icon_bullet');
function zbx_icon_bullet($atts, $content = null)
{

	$default_atts = array(
		'heading' => '',
		'circle'  => '',
		'mb'      => '',
		'size'    => '',
	);

	$default_atts = array_merge($default_atts, zbx_sc::get_icon_atts());

	$atts = shortcode_atts($default_atts, $atts);

	$atts = zbx_sc::icon($atts);

	$class = zbx::join($atts['circle'], $atts['size']);

	return sprintf('<div %s class="bullet %s"><i class="zx-icon %s" %s></i>%s</div>',
		zbx_sc::get_format_style_esc('margin-bottom', esc_attr((int)$atts['mb'])),
		esc_attr($class),
		esc_attr($atts['icon']),
		zbx_sc::get_format_style_esc( 'color', $atts['icon_color'] ),
		wp_kses_post($content)
	);
}
