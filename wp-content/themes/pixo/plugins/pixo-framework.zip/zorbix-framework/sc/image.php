<?php

add_shortcode('image', 'zbx_image');
function zbx_image($atts, $content = null)
{

	$v = array(
		'image_id'       => '',
		'circle'         => '',
		'size'           => '',
		'full_width' => '',
		'padding'        => '',
		'padding_top'    => '',
		'padding_right'  => '',
		'padding_bottom' => '',
		'padding_left'   => '',
		'width' => '',
		'link' => '',
	);
	$v = shortcode_atts($v, $atts);


	$class = zbx::join(
		zbx_sc::class_from_key('circle', $v),
		zbx_sc::class_from_key('full_width', $v)
	);

	$src = zbx_img::get_src_from_id($v['image_id'], $v['size'], true, $class);

	$output = zbx_sc::get_opening_anchor($v['link']);

	$output .= sprintf('<img src="%s" %s  %s alt="image"/>',
		esc_url($src),
		zbx_sc::escaped_class_attr($class),
		zbx_sc::get_format_style_esc_multi(array(
			'padding'        => $v['padding'],
			'padding-top'    => $v['padding_top'],
			'padding-right'  => $v['padding_right'],
			'padding-bottom' => $v['padding_bottom'],
			'padding-left'   => $v['padding_left'],
			'width' => $v['width'],
		))
	);

	$output .= zbx_sc::get_closing_anchor($v['link']);

	return $output;
}