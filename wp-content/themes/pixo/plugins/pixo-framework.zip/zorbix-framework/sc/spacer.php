<?php

add_shortcode( 'spacer', 'zbx_spacer' );
function zbx_spacer( $atts, $content = null ) {


	return sprintf( '<div style="margin-bottom:%spx"></div>',
		esc_attr( zbx_sc::remove_px( $content ) )
	);

}