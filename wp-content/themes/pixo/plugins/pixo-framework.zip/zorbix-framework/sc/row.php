<?php

add_shortcode( 'row', 'zbx_row');
function zbx_row($set_atts, $content = null ) {

	$atts = array(
		'margin_bottom' => '',
	);

	$atts = zbx_sc::shortcode_atts( $atts, $set_atts, 'row' );

	$html = '<div class="row" ' . zbx_sc::get_format_style_esc( 'margin-bottom', $atts['margin_bottom'] ) . '>';
	$html .= do_shortcode( $content );
	$html .= '</div>';

	return $html;
}