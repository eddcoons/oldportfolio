<?php

add_shortcode('nested-column', 'zbx_nested_column');
function zbx_nested_column($user_atts, $content = null)
{

	$v = array(
			'size'        => '', // col-md-3
			'width_lg'    => '', // col-lg-3
			'width_sm'    => '', // col-sm-3
			'width_xs'    => '', // col-sm-3
			'mb_lg'         => '',
			'mb_md'         => '',
			'mb_sm'         => '',
			'mb_xs'         => '',
			'bg_color'    => '',
			'bg_id'       => '',
			'inline'      => 'false',
			'bg_pos'      => '',
			'bg_size'     => '',
			'cols_equal'  => 'false',
			'center_text' => '',
			'cell'        => ''

	);

	$v = zbx_sc::get_attr_set($v, array('margin', 'padding'));
	$v = shortcode_atts($v, $user_atts);

	$image_url = zbx_img::get_src_from_id($v['bg_id']);

	$class = zbx::join(
			'col',
			zbx_sc::class_from_key('center_text', $v),
			zbx_sc::class_from_key('cols_equal', $v),
			zbx_sc::prepend($v['bg_size'], 'bg-'),
			zbx_sc::prepend($v['bg_pos'], 'bg-'),
			zbx_sc::prepend($v['mb_xs'], 'mb-xs-'),
			zbx_sc::prepend($v['mb_sm'], 'mb-sm-'),
			zbx_sc::prepend($v['mb_md'], 'mb-md-'),
			zbx_sc::prepend($v['mb_lg'], 'mb-lg-'),
			zbx::if_true($v['cell'], 'cell'),
			$v['size'],
			$v['width_lg'],
			$v['width_sm'],
			$v['width_xs']
	);

	return sprintf('<div class="%s" %s>%s</div>',
			$class,
			zbx_sc::get_format_style_esc_multi(
					zbx_sc::get_style_atts('spacing', $v),
					array(
							'background-color' => $v['bg_color'],
							'background-image' => $image_url,
					)),
			do_shortcode($content)
	);
}
