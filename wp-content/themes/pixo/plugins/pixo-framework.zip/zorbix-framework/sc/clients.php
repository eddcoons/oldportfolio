<?php

add_shortcode( 'clients', 'zbx_client');
function zbx_client($atts, $content = null ) {

	$post_type = 'client';
	$taxonomy  = 'client_group';

	$default_atts = array(
		'link'         => '',
		'id'           => '',
		'hover_effect' => 'false',
		'height'       => '',
	);

	// Add a predefined set of attributes
	$default_atts = zbx_sc::get_attr_set( $default_atts, array( 'animation' ) );
	$atts         = zbx_sc::shortcode_atts( $default_atts, $atts, 'clients' );

	$class = zbx::join(
		zbx_sc::animation_class( $atts ),
		zbx::if_true( 'true' === $atts['hover_effect'], 'hover-effect' )
	);

	$output = sprintf( '<div  class="client %s" %s>',
		esc_attr( $class ),
		zbx_anim_data_esc( $atts ),
		zbx_sc::format_style_esc( 'height', $atts['height'] )
	);

	$output .= zbx_sc::get_opening_anchor( $atts['link'] );
	$output .= zbx_img::get_tag_from_id( $atts['id'], 'pixo_client_thumb', true );
	$output .= zbx_sc::get_closing_anchor( $atts['link'] );

	$output .= '</div>';

	return $output;
}
