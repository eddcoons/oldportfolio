<?php

add_shortcode( 'bgvideo', 'zbx_bgvideo');
function zbx_bgvideo($atts, $content = null ) {

	$default_atts = array(
		'mp4'    => '',
		'webm'   => '',
		'ogv'    => '',
		'poster' => '',
		'height' => '',
		'width'  => '',
	);

	$atts = zbx_sc::shortcode_atts( $default_atts, $atts, 'zbx_video' );

	$atts['poster'] = zbx_img::get_src_from_id( $atts['poster'] );

	return zbx_sc::get_video_background( 'upload', '', $content, '' );

	//[video mp4="source.mp4" ogv="source.ogv" mov="source.mov"]


}
