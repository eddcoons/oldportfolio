<?php

add_action( 'admin_init', 'zbx_testimonial_meta_boxes' );
function zbx_testimonial_meta_boxes() {

	zbx_mb::create( array(
		'id'       => 'testimonials',
		'title'    => esc_html__( 'Options', 'zorbix' ),
		'desc'     => '',
		'pages'    => array( 'testimonial' ),
		'context'  => 'normal',
		'priority' => 'high',
		'fields'   => array(
			array( // Author
				'type'  => 'text',
				'id'    => 'author',
				'label' => esc_html__( 'Author', 'zorbix' ),
			),
			array(
				'type'  => 'textarea',
				'id'    => 'quote',
				'label' => esc_html__( 'Quote', 'zorbix' ),
			),
		),
	) );
}

add_shortcode( 'testimonials', 'zbx_testimonials' );
function zbx_testimonials( $atts ) {

	$default_atts = array(
			'center_text' => '',
			'margin_bottom' => '40',
	);
	$sets         = array( 'makewhite', 'animation', 'cpt' );
	$default_atts = zbx_sc::get_attr_set( $default_atts, $sets );
	$atts         = zbx_sc::shortcode_atts( $default_atts, $atts, 'team' );

	$cpt_posts = zbx_sc::cpt( array(
		'post_type' => 'testimonial',
		'tax'       => 'testimonial_slider',
		'atts'      => $atts,
	) );

	$class = zbx_sc::class_from_key( 'center_text', $atts );

	ob_start(); ?>

	<!-- TESTIMONIALS -->
	<div class="testimonials <?php echo esc_attr( $class ) ?>" <?php zbx_sc::format_style_esc( 'margin-bottom', $atts['margin_bottom'] )  ?>>
		<ul class="testimonial bxslider">

			<?php if ( $cpt_posts->have_posts() ) : while ( $cpt_posts->have_posts() ) : $cpt_posts->the_post();

				$quote  = zbx_mb::get( 'quote' );
				$author = zbx_mb::get( 'author' );
				?>

				<li>
					<?php // Thumb or quote icon
					if ( get_the_post_thumbnail() ) {
						zbx_img::thumb_tag( ZORBIX_PREFIX . '400_square' );
					} ?>
					<h1 class="quote"><?php echo esc_html( $quote ) ?></h1>

					<p class="author"><?php echo esc_html( $author ) ?></p>
				</li>
			<?php endwhile; endif; ?>

		</ul>
		<!-- End .testimonial -->
	</div><!-- End .container -->

	<?php return ob_get_clean();

}
