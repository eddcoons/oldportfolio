<?php

add_shortcode( 'mobile_margins', 'zbx_mobile_margins' );
function zbx_mobile_margins( $atts, $content = null ) {

	$default_atts = array(
		'margin_bottom' => '20',
		'breakpoint'    => 'sm',
	);

	$atts = shortcode_atts( $default_atts, $atts );

	return sprintf( '<div class="mb-%s-%s"></div>',
		esc_attr( zbx_sc::remove_px( $atts['margin_bottom'] ) ),
		esc_attr( $atts['breakpoint'] ) );

}