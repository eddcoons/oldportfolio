<?php

add_shortcode( 'container', 'zbx_container');
function zbx_container($atts, $content = null ) {

	return sprintf( '<div class="container">%s</div>', do_shortcode( $content ) );

}