<?php

add_shortcode( 'sub-heading', 'zbx_sub_heading' );
function zbx_sub_heading( $atts, $content = null ) {

	return sprintf( '<span class="page-sub-heading">%s</span>', wp_kses_post( $content ) );

}