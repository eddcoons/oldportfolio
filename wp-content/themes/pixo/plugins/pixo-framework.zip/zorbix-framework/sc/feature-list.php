<?php

add_shortcode('feature-list', 'zbx_feature_list');
function zbx_feature_list($atts, $content = null)
{

	$default_atts = array(
		'link'             => '',
		'heading'          => '',
		'hexcolor'         => '#f5f5f5',
		'icon_color'       => '',
		'content'          => '',
		'align'            => 'left',
		'mb'               => '',
		'size'             => '',
		// Animation atts
		'animate_check'    => '',
		'start_delay'      => '',
		'effect'           => '',
		'delay'            => '',
		// Icon atts
		'icon'             => '',
		'icon_type'        => 'font-awesome',
		'icon_fontawesome' => 'fa-info',
		'icon_openiconic'  => '',
		'icon_typicons'    => '',
		'icon_entypoicons' => '',
		'icon_linecons'    => '',
		'icon_entypo'      => '',
		'icon_border'      => '',
	);

	$atts = shortcode_atts($default_atts, $atts);

	$animation_class = zbx_sc::animation_class($atts);
	$class = zbx::join(
		'feature-list-item',
		$animation_class,
		$atts['align'],
		$atts['size']
	);

	# HTML
	$mb = (int)$atts['mb'];
	$atts['style'] = ($atts['mb']) ? "margin-bottom: {$mb}px" : '';

	ob_start();

	printf('<div class="%s" style="%s" %s >',
		esc_attr($class),
		esc_attr($atts['style']),
		zbx_anim_data_esc($atts)
	);

	zbx_sc::print_icon($atts);

	echo '<h4 class="title">';
	zbx_sc::print_opening_anchor($atts['link']);
	echo esc_html($atts['heading']);
	zbx_sc::print_closing_anchor($atts['link']);
	echo '</h4>';

	echo wpautop($content);
	echo '</div>';

	return ob_get_clean();
}
