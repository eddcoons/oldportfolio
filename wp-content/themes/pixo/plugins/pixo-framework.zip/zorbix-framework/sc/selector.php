<?php

# PORTFOLIO METABOXES


add_shortcode( 'selector', 'zbx_selector' );
function zbx_selector( $atts, $content ) {

	$class = '';

	$default_atts = array(
		'layout'      => '',
		'height'      => '',
		'width'       => '',
	);

	# Set Attributes
	$atts = zbx_sc::shortcode_atts( $default_atts, $atts, 'gallery' );


//	zbx::log(zbx::if_true( ! empty( $atts['width'] ), ' w-' . zbx::fraction_to_words( $atts['width'] ) ) );
//	zbx::log(zbx::if_true( ! empty( $atts['height'] ), ' h-' . zbx::fraction_to_words( $atts['height'] ) ) );
//	zbx::log( $atts['width'], 'width' );
//	zbx::log( $atts['height'], 'height' );

	$class = zbx::join(
		zbx::if_true( ! empty( $atts['width'] ), ' w-' . zbx::fraction_to_words( $atts['width'] ) ),
		zbx::if_true( ! empty( $atts['height'] ), ' h-' . zbx::fraction_to_words( $atts['height'] ) ),
		$atts['layout']
	);


	# Generate HTML
	ob_start(); ?>

	<div class="selector <?php echo esc_attr( $class ) ?> ">

		<?php echo do_shortcode( $content ); ?>

	</div>

	<?php return ob_get_clean();
}
