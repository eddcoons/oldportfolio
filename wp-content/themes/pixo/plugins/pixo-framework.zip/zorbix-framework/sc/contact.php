<?php


add_shortcode('contact', 'zbx_contact_form');
function zbx_contact_form($atts_set)
{

	$default_atts = array(
		'name'       => esc_html__('name', 'zorbix'),
		'email'      => esc_html__('email', 'zorbix'),
		'subject'    => esc_html__('subject', 'zorbix'),
		'message'    => esc_html__('message', 'zorbix'),
		'button'     => esc_html__('SEND', 'zorbix'),
		'layout'     => '1',
		'align_left' => ''
	);


	# Set Attributes
	$atts = zbx_sc::shortcode_atts($default_atts, $atts_set, 'portfolio');

	$atts['class'] = 'contact-form ' . zbx_sc::class_from_key( 'align_left', $atts);

	ob_start();

	zbx::load_template_part('contactforms/form', $atts['layout'], $atts);

	return ob_get_clean();

}