<?php


if ( ! ( function_exists( 'zbx_limit_excerpt' ) ) ) {
	function zbx_limit_excerpt( $limit, $source = null ) {
		if ( $source === 'content' ? ( $excerpt = get_the_content() ) : ( $excerpt = get_the_excerpt() ) ) {
		}

		$excerpt       = preg_replace( ' (\[.*?\])', '', $excerpt );
		$excerpt       = strip_shortcodes( $excerpt );
		$excerpt       = strip_tags( $excerpt );
		$length_before = strlen( $excerpt );
		$excerpt       = substr( $excerpt, 0, $limit );
		$length_after  = strlen( $excerpt );
		$excerpt       = substr( $excerpt, 0, strripos( $excerpt, ' ' ) );

		$excerpt = trim( preg_replace( '/\s+/', ' ', $excerpt ) );
		// Add dots to all but those with out any text.
		if ( strlen( $excerpt ) !== 0 ) {
			return $excerpt . '<a class="more" href="' . esc_url( get_permalink( get_the_id() ) ) . '">...</a>';
		} else {
			return $excerpt;
		}
	}

}

add_shortcode( 'latest_posts', 'zbx_latest_posts' );

function zbx_latest_posts( $atts ) {

	$post_type    = 'post';
	$taxonomy     = 'category';
	$sets         = array( 'cpt', 'animation', 'column' );
	$default_atts = array(
		'images' => 'false',
		'disable_post_types' => 'false',
	);

	$default_atts    = zbx_sc::get_attr_set( $default_atts, $sets );
	$atts            = shortcode_atts( $default_atts, $atts, 'latest_posts' );
	$animation_class = zbx_sc::animation_class( $atts );

	$cpt_posts = zbx_sc::cpt( array(
		'post_type' => $post_type,
		'tax'       => $taxonomy,
		'atts'      => $atts,
	) );

	$comments_meta_bool =  ( class_exists( 'zbx_settings' ) ) ? zbx_settings::get_option( 'meta_comments' ) : true;

	ob_start(); ?>
	<div class="latest-posts">
		<?php if ( $cpt_posts->have_posts() ) : while ( $cpt_posts->have_posts() ) : $cpt_posts->the_post();

		$class = "$animation_class {$atts['col_width']} col col-sm-6";
//$class ='';

		$zorbix['quote']        = zbx_mb::get( 'quote' );
		$zorbix['quote_url']    = zbx_mb::get( 'link' );
		$zorbix['quote_author'] = zbx_mb::get( 'author' );

		printf( '<div class="%s" %s >',
			esc_attr( $class ),
			zbx_anim_data_esc( $atts, $cpt_posts )
		);

		?><div class="post"><?php

		# Get formatted link
		if( 'true' !== $atts['disable_post_types'] && defined('ZORBIX_VERSION') ) { // only look for if theme is loaded.
			include( locate_template( 'partials/blog-link.php' ) );
		} ?>

		<?php
		if ( has_post_thumbnail() && 'true' !== $atts['images'] ) : ?>
		<!-- Blog Media -->
		<a href="<?php the_permalink() ?>" class="blog-media">
			<?php zbx_img::thumb_tag( 'zbx_blog_thumb' ); ?>
		</a>
		<?php endif; ?>

		<div class="post-content">
		<h4 class="title"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h4>


		<?php echo zbx_limit_excerpt( 150 ); ?>

		<hr/>

		<div class="blog-meta">
			<?php the_author_posts_link() ?> -
			<?php the_time( 'd M' ); ?>
			<?php echo ( $comments_meta_bool ) ? comments_number( '',
				' - one <a class="smooth_jump" href="#comments">comment</a>',
				' - % <a class="smooth_jump" href="#comments">comments</a>' ) : ''; ?>
		</div>

		</div>

		</div>
		</div>
		<?php
//		zbx_sc::col_seperator( $cpt_posts, 3, $atts['col_width'] );

	endwhile; endif;
	?>
	</div>

	<?php return $output = ob_get_clean();

}

;
