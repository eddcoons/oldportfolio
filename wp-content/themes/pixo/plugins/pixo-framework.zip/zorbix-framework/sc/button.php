<?php
# Features Map

add_shortcode( 'button', 'zbx_button' );
function zbx_button( $atts, $content = null ) {

	$default_atts = array(
		'style'            => 'btn-default',
		'heading' => '',
		'backbtn'          => '',
		'link'             => '',
		'target'           => '',
		'title'            => '',
		'size'             => '',
		'margin'           => '',
		'block'            => '',
		'center_text'      => '',
		'icon_type'        => '',
		'icon_fontawesome' => '',
		'icon_openiconic'  => '',
		'icon_typicons'    => '',
		'icon_entypoicons' => '',
			'icon_color' => '',
		'icon_linecons'    => '',
		'icon_entypo'      => '',
		'smooth_jump'      => '',
	);

	$atts = zbx_sc::shortcode_atts( $default_atts, $atts, 'button' );

//	$link_atts = zbx_sc::sc_link( $atts );

	// Set class
	$class = zbx::join(
		'btn',
		$atts['style'],
		$atts['size'],
		zbx::if_true( $atts['backbtn'], ' btn-back' ),
		zbx::if_true( $atts['smooth_jump'], ' smooth-jump' )
	);
	$style = ( $atts['margin'] ) ? 'margin: ' . $atts['margin'] : '';

	$atts['center_text'] = zbx_sc::class_from_key( 'center_text', $atts );

	/* Opening Block */
	$output = zbx::if_str_true( $atts['block'], '<div class="' . $atts['center_text'] . '">' );

		/* Opening Anchor */
	$link        = zbx_sc::attr_link_format( $atts['link'] );
	$output .= $atts['link'];
	$link['url'] = zbx::if_empty( $link['url'], '#' );
	$output .= zbx_sc::get_opening_anchor( $link, $class, $style );

	/* Icon */
	$output.= zbx_sc::get_print_icon( $atts );

	/* Content */
	$output .= esc_html( $atts['heading'] );

	/* Closing Anchor */
	$output .=  '</a>';

	/* Closing block */
	$output .= zbx::if_true( $atts['block'], '</div>' );

	return $output;
	?>

<?php }
