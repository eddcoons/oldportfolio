<?php ob_start(); ?>

[row margin_bottom=90][/row]

<?php echo( do_shortcode( ob_get_clean() ) );