<?php

zbx::pretty_dump(get_theme_mods());