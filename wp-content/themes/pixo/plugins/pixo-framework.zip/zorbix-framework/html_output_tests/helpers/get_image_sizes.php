<?php

echo 'Image Sizes';
var_dump( get_intermediate_image_sizes() );
