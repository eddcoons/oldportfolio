<?php ob_start(); ?>

	[heading heading="GET A QUOTE" margin_bottom="90" dash=true]

<?php echo( do_shortcode( ob_get_clean() ) );