<?php ob_start(); ?>
[flipping-circle image_id=3444]
<?php echo( do_shortcode( ob_get_clean() ) );