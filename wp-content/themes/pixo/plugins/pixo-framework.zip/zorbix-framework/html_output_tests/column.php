<?php ob_start(); ?>

[column mb_sm=10 padding="100px 20px 100px 100px"]

<?php echo( do_shortcode( ob_get_clean() ) );