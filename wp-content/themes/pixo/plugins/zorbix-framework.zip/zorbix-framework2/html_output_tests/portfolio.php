<?php ob_start(); ?>

[portfolio gutter=true]

<?php echo( do_shortcode( ob_get_clean() ) );