<?php

zorbix::pretty_dump(get_theme_mods());