<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 22/12/2015
 * Time: 14:16
 */

// Shows all post meta for id
$post_id = '';
get_post_meta( $post_id );

