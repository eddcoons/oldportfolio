<?php
$str = <<<EOF

		[latest_posts num="3" images=false]


EOF;

echo(do_shortcode($str));