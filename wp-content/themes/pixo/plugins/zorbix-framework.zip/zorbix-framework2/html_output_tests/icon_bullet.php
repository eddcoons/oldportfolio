<?php ob_start(); ?>

	[icon_bullet heading="Google" size="small" mb="20" icon_fontawesome="fa-user"][/icon_bullet]

<?php echo( do_shortcode( ob_get_clean() ) );