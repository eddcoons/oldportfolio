<?php ob_start(); ?>

	[testimonials center_text=true margin_bottom=90][/testimonials]

<?php echo( do_shortcode( ob_get_clean() ) );