<?php ob_start(); ?>

[separator color="red"]

<?php echo( do_shortcode( ob_get_clean() ) );