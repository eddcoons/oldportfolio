<?php ob_start(); ?>

[sharing twitter=true google=true facebook=true]

<?php echo( do_shortcode( ob_get_clean() ) );