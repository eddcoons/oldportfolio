<?php ob_start(); ?>
[feature-list]

<?php echo( do_shortcode( ob_get_clean() ) );