<div class="images">

</div>
<input class="<?php echo esc_attr( $type ) ?>" type="text" name="<?php echo esc_attr( $param_name ) ?>"
       value="<?php echo esc_attr( $preset_value_for_field ) ?>">
<input class="zbx-media-btn" class="button" name="zbx-media-btn" type="text" value="Upload" />
