
<input id="<?php echo esc_attr( $type ) ?>" class="<?php echo esc_attr( $type ) ?>" type="text" name="<?php echo esc_attr( $param_name ) ?>"
       value="<?php echo esc_attr( $preset_value_for_field ) ?>">
